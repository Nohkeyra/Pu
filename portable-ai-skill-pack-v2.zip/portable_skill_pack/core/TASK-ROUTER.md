# Automatic Skill Orchestrator

## Purpose
Automatically determine which skills and workflow stages are required for the current task. The user should not need to name skills manually.

## Routing procedure
1. Parse the requested outcome, scope, constraints, risk, and expected deliverable.
2. Classify the task into one or more modes: audit, implementation, debugging, security, refactor/simplification, verification, research/exploration, or mixed.
3. Estimate complexity: LOW, MEDIUM, HIGH, or CRITICAL.
4. Identify affected surfaces: UI, state, business logic, API, database, auth, infrastructure, build/deploy, performance, security, tests.
5. Select the minimum sufficient skill set. Add a skill whenever its omission would materially weaken correctness, safety, or verification.
6. Resolve dependencies: implementation normally requires verification; debugging requires verification; security findings require verification when a fix is made; broad audits may require multiple skills.
7. Do not load irrelevant skills merely for completeness.
8. If evidence changes the task classification, re-route before continuing.

## Default routing matrix
| Task signal | Activate |
|---|---|
| Whole-project audit/review | code-audit + verification; add security-review and simplification when relevant |
| Bug/error/failing build | debugging + verification |
| Authentication, authorization, secrets, data exposure | security-review + code-audit + verification |
| Refactor/cleanup/performance simplification | simplification + verification; add code-audit if behavior may change |
| New feature/implementation | code-audit + verification; add debugging/security/simplification as triggered by scope |
| UI/UX implementation or correction | code-audit + verification; inspect actual UI evidence when available |
| Final validation/release readiness | verification + code-audit; add security-review for security-sensitive systems |

## Complexity policy
- LOW: narrow change, localized reasoning, focused verification.
- MEDIUM: multiple files/components or meaningful behavior change; use explicit plan and verification.
- HIGH: cross-cutting changes, architecture, auth/data, production-impacting behavior, or uncertain root cause; use full-engineering workflow.
- CRITICAL: destructive, security-critical, migration, deployment, or irreversible operations; require explicit confirmation where appropriate and maximize verification.

## Activation declaration
Before substantive work, internally establish:
- Task classification
- Complexity
- Activated skills
- Selected workflow
- Key evidence needed
- Verification gate

Expose this summary to the user when useful, especially for non-trivial work. Do not waste output on ceremonial declarations for trivial tasks.

## Re-routing rule
Skill selection is dynamic, not a one-time decision. If new evidence reveals security, architectural, regression, or debugging concerns, activate the additional relevant skill before proceeding.
